const { S3Client, GetObjectCommand } = require('@aws-sdk/client-s3');
const { parse } = require('csv-parse');
const {
  DynamoDBClient,
  BatchWriteItemCommand,
} = require('@aws-sdk/client-dynamodb');

const clientS3 = new S3Client({
  region: 'us-east-1',
  credentials: {
    accessKeyId: 'test',
    secretAccessKey: 'test',
  },
});

async function getObject(bucket, file) {
  const response = await clientS3.send(
    new GetObjectCommand({
      Bucket: bucket,
      Key: file,
    }),
  );
  return response.Body;
}

const dynamoDBClient = new DynamoDBClient({
  region: 'us-east-1',
  credentials: {
    accessKeyId: 'test',
    secretAccessKey: 'test',
  },
});

const handler = async event => {
  const { s3 } = event.Records[0];
  try {
    const file = await getObject(s3.bucket.name, s3.object.key);
    const name = s3.object.key.split('.')[0];
    const batch_of_rows = [];
    let batch_of_items = [];
    let page = 0;
    const chunks = await file.pipe(parse({ delimiter: ',', columns: true }));
    for await (const record of chunks) {
      if (batch_of_items.length === 25) {
        batch_of_rows.push({
          identifier: { S: `${name}-${page}` },
          payload: { S: JSON.stringify(batch_of_items) },
        });
        page += 1;
        batch_of_items = [];
      } else {
        batch_of_items.push(record);
      }
    }
    let batches = [];
    const batche_of_promise = [];
    for (const item of batch_of_rows) {
      const params = {
        PutRequest: {
          Item: {
            identifier: item.identifier,
            payload: item.payload,
          },
        },
      };
      if (batches.length === 10) {
        batche_of_promise.push({
          RequestItems: {
            credentials: batches,
          },
        });
        batches = [];
      } else {
        batches.push(params);
      }
    }

    const promises = [];
    for (const batch of batche_of_promise) {
      promises.push(dynamoDBClient.send(new BatchWriteItemCommand(batch)));
    }
    await Promise.all(promises);
    console.log('Stored in DynamoDB successfully!');
  } catch (error) {
    console.error('Error send data to DynamoDB', error);
    throw error;
  }
};
exports.handler = handler;
