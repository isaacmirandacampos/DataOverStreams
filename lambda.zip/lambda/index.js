const { S3Client, GetObjectCommand } = require('@aws-sdk/client-s3');
const { parse } = require('csv-parse');
const {
  DynamoDBClient,
  BatchWriteItemCommand,
} = require('@aws-sdk/client-dynamodb');

const clientS3 = new S3Client({
  region: 'us-east-1',
  credentials: {
    accessKeyId: 'test',
    secretAccessKey: 'test',
  },
});

async function getObject(bucket, file) {
  const response = await clientS3.send(
    new GetObjectCommand({
      Bucket: bucket,
      Key: file,
    }),
  );
  return response.Body;
}

const dynamoDBClient = new DynamoDBClient({
  region: 'us-east-1',
  credentials: {
    accessKeyId: 'test',
    secretAccessKey: 'test',
  },
});

function parserArrayToDynamoDB(array) {
  return array.map(item => ({
    PutRequest: {
      Item: {
        identifier_code: { S: item.identifier_code },
        name: { S: item.name },
      },
    },
  }));
}

const handler = async event => {
  const { s3 } = event.Records[0];
  try {
    const file = await getObject(s3.bucket.name, s3.object.key);
    const batches = [];
    let batch = [];
    const parser = await file.pipe(parse({ delimiter: ',', columns: true }));
    for await (const record of parser) {
      if (batch.length >= 25) {
        batches.push(batch);
        batch = [];
      } else {
        batch.push(record);
      }
    }
    const promises = [];
    for (const item of batches) {
      const params = {
        RequestItems: {
          credentials: parserArrayToDynamoDB(item),
        },
      };
      promises.push(dynamoDBClient.send(new BatchWriteItemCommand(params)));
    }
    await Promise.all(promises);
    console.log('Stored in DynamoDB successfully!');
  } catch (error) {
    console.error('Error send data to DynamoDB', error);
    throw error;
  }
};
exports.handler = handler;
